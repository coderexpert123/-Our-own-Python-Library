from setuptools import setup,find_packages
setup(
          name="pc",
          version="0.1",
            description="my packaes ",
            author="Nishant",
             packages=["pc"],
            install_requires=[]



      )
