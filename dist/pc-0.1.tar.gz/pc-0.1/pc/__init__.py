def f(number):
    print("tis is numer")

    return  number